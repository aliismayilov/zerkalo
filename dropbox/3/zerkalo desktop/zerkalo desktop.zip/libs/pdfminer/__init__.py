#!/usr/bin/env python2
__version__ = '20110515'

if __name__ == '__main__': print __version__
